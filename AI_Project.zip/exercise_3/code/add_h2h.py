import csv
import numpy as np
import math
from datetime import datetime

games = []

with open('data/new_odd_combine_data.csv', 'r', encoding="utf8", errors='ignore') as f:
    reader = csv.DictReader(f)
    for row in reader:
        games.append(row)

h2h_list = []

def weight_games(arr):
    return sum([k[0] * 1 / (k[1]+1) for k in arr])





for i, game in enumerate(games):
    h2h_win_clean = 0
    h2h_goal_clean = 0
    h2h = [[0, 0]]
    count = 0
    curr_date = datetime.strptime(game['Date'][0:10], '%d/%m/%Y')
    curr_season = curr_date.year - 2006
    if curr_date.month > 7:
        curr_season += 1

    for k in sorted(range(i), reverse=True):
        if games[k]['Date'] != game['Date']:
            prev_date = datetime.strptime(games[k]['Date'][0:10], '%d/%m/%Y')
            prev_season = prev_date.year - 2006
            if prev_date.month > 7:
                prev_season += 1
            diff_season = curr_season - prev_season
            if games[k]['HomeTeam'] == game['HomeTeam'] and games[k]['AwayTeam'] == game['AwayTeam']:
                if games[k]['RESULT'] == 'HOME':
                    h2h_win_clean += 1
                    h2h_goal_clean += int(game['home_goal'])
                    if diff_season == h2h[len(h2h)-1][1]:
                        h2h[len(h2h)-1][0] += 1
                    else:
                        h2h.append([1, diff_season])
                if games[k]['RESULT'] == 'AWAY':
                    h2h_win_clean -= 1
                    h2h_goal_clean -= int(game['away_goal'])
                    if diff_season == h2h[len(h2h)-1][1]:
                        h2h[len(h2h)-1][0] -= 1
                    else:
                        h2h.append([-1, diff_season])
                count += 1
                #if count == 5:
                #    break
            if games[k]['HomeTeam'] == game['AwayTeam'] and games[k]['AwayTeam'] == game['HomeTeam']:
                if games[k]['RESULT'] == 'HOME':
                    h2h_win_clean -= 1
                    h2h_goal_clean -= int(game['home_goal'])
                    if diff_season == h2h[len(h2h)-1][1]:
                        h2h[len(h2h)-1][0] -= 1
                    else:
                        h2h.append([-1, diff_season])
                if games[k]['RESULT'] == 'AWAY':
                    h2h_win_clean += 1
                    h2h_goal_clean += int(game['away_goal'])
                    if diff_season == h2h[len(h2h)-1][1]:
                        h2h[len(h2h)-1][0] += 1
                    else:
                        h2h.append([1, diff_season])
                count += 1
                #if count == 5:
                #    break
    h2h_list.append([h2h_win_clean, h2h_goal_clean, weight_games(h2h)])

print(len(h2h_list))
with open('data/new_odd_2_combine_data.csv', 'w', newline='') as csvfile:
    fieldnames = ['Date', 'HomeTeam', 'AwayTeam', 'h_played', 'h_played_h', 'a_played',
                  'a_played_a', 'h_won', 'h_won_h', 'h_drawn', 'h_drawn_h', 'h_lost', 'h_lost_h',
                  'h_points', 'h_points_h', 'h_scored', 'h_scored_h', 'h_conced', 'h_conced_h',
                  'h_clean', 'h_clean_h', 'h_fail', 'h_fail_h',

                  # new
                  'h_goal_diff', 'h_goal_diff_h',
                  'h_shots', 'h_shots_h', 'h_shots_against', 'h_shots_against_h',
                  'h_shots_target', 'h_shots_target_h', 'h_shots_target_against', 'h_shots_target_against_h',
                  'h_shots_diff_h', 'h_shots_diff',
                  'h_shots_target_diff',
                  'h_shots_target_diff_h',

                  # 'h_hit_woodwork', 'h_hit_woodwork_h',
                  # 'h_hit_woodwork_against', 'h_hit_woodwork_diff',
                  'h_red_cards', 'h_red_cards_h',
                  'h_red_cards_against', 'h_red_cards_diff',
                  'h_red_cards_against_h', 'h_red_cards_diff_h',
                  'h_elo', 'h_fifa_rating',
                  'h_current_win_streak', 'h_current_no_lose_streak',
                  'h_current_lose_streak', 'h_current_no_win_streak',
                  'h_last_5_games_points', 'h_last_5_games_wins', 'h_last_5_games_loss',
                  'h_last_5_games_draw', 'h_last_5_games_scored', 'h_last_5_games_conced',
                  'h_last_5_games_goal_diff', 'h_last_5_games_clean', 'h_last_5_games_failed',

                  'a_won', 'a_won_a', 'a_drawn', 'a_drawn_a', 'a_lost', 'a_lost_a',
                  'a_points', 'a_points_a', 'a_scored', 'a_scored_a', 'a_conced', 'a_conced_a',
                  'a_clean', 'a_clean_a', 'a_fail', 'a_fail_a',

                  # new
                  'a_goal_diff', 'a_goal_diff_a',
                  'a_shots', 'a_shots_a', 'a_shots_against', 'a_shots_against_a',
                  'a_shots_target', 'a_shots_target_a', 'a_shots_target_against', 'a_shots_target_against_a',
                  'a_shots_diff_a', 'a_shots_diff',
                  'a_shots_target_diff',
                  'a_shots_target_diff_a',
                  # 'a_hit_woodwork', 'a_hit_woodwork_a',
                  # 'a_hit_woodwork_against', 'a_hit_woodwork_diff',
                  'a_red_cards', 'a_red_cards_a',
                  'a_red_cards_against', 'a_red_cards_diff',
                  'a_red_cards_against_a', 'a_red_cards_diff_a',
                  'a_elo', 'a_fifa_rating',
                  'a_current_win_streak', 'a_current_no_lose_streak',
                  'a_current_lose_streak', 'a_current_no_win_streak',
                  'a_last_5_games_points', 'a_last_5_games_wins', 'a_last_5_games_loss',
                  'a_last_5_games_draw', 'a_last_5_games_scored', 'a_last_5_games_conced',
                  'a_last_5_games_goal_diff', 'a_last_5_games_clean', 'a_last_5_games_failed',
                  'h2h_win_clean', 'h2h_goal_clean', 'h2h_weight',

                  'home_odd',
                  'draw_odd', 'away_odd',
                  'home_odd_3', 'draw_odd_3', 'away_odd_3',
                  'RESULT']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for i, game_state in enumerate(games):
        print(h2h_list[i])
        writer.writerow(
            {'Date': game_state['Date'], 'HomeTeam': game_state['HomeTeam'], 'AwayTeam': game_state['AwayTeam'],
             'h_played': game_state['h_played'], 'h_played_h': game_state['h_played_h'],
             'a_played': game_state['a_played'],
             'a_played_a': game_state['a_played_a'], 'h_won': game_state['h_won'], 'h_won_h': game_state['h_won_h'],
             'h_drawn': game_state['h_drawn'], 'h_drawn_h': game_state['h_drawn_h'], 'h_lost': game_state['h_lost'],
             'h_lost_h': game_state['h_lost_h'], 'h_points': game_state['h_points'],
             'h_points_h': game_state['h_points_h'],
             'h_scored': game_state['h_scored'], 'h_scored_h': game_state['h_scored_h'],
             'h_conced': game_state['h_conced'],
             'h_conced_h': game_state['h_conced_h'], 'h_clean': game_state['h_clean'],
             'h_clean_h': game_state['h_clean_h'],
             'h_fail': game_state['h_fail'], 'h_fail_h': game_state['h_fail_h'],
             # new away
             # goals
             'h_goal_diff': game_state['h_goal_diff'],
             'h_goal_diff_h': game_state['h_goal_diff_h'],

             'h_shots': game_state['h_shots'], 'h_shots_h': game_state['h_scored_h'],
             'h_shots_against': game_state['h_shots_against'], 'h_shots_against_h': game_state['h_shots_against_h'],
             'h_shots_target': game_state['h_shots_target'], 'h_shots_target_h': game_state['h_shots_target_h'],
             'h_shots_diff_h': game_state['h_shots_diff_h'], 'h_shots_diff': game_state['h_shots_diff'],
             'h_shots_target_against': game_state['h_shots_target_against'],
             'h_shots_target_against_h': game_state['h_shots_target_against_h'],
             'h_shots_target_diff': game_state['h_shots_target_diff'],
             'h_shots_target_diff_h': game_state['h_shots_target_diff_h'],
             # hit woodwork
             # 'h_hit_woodwork': game_state['h_hit_woodwork'],
             # 'h_hit_woodwork_h': game_state['h_hit_woodwork_h'],
             # 'h_hit_woodwork_against': game_state['h_hit_woodwork_against'],
             # 'h_hit_woodwork_diff': game_state['h_hit_woodwork_diff'],
             # cards
             'h_red_cards': game_state['h_red_cards'], 'h_red_cards_h': game_state['h_red_cards_h'],
             'h_red_cards_against': game_state['h_red_cards_against'],
             'h_red_cards_diff': game_state['h_red_cards_diff'],
             'h_red_cards_against_h': game_state['h_red_cards_against_h'],
             'h_red_cards_diff_h': game_state['h_red_cards_diff_h'],
             # ranking
             'h_elo': game_state['h_elo'], 'h_fifa_rating': game_state['h_fifa_rating'],
             # streaks
             'h_current_win_streak': game_state['h_current_win_streak'],
             'h_current_no_lose_streak': game_state['h_current_no_lose_streak'],
             'h_current_lose_streak': game_state['h_current_lose_streak'],
             'h_current_no_win_streak': game_state['h_current_no_win_streak'],
             # last status
             'h_last_5_games_points': game_state['h_last_5_games_points'],
             'h_last_5_games_wins': game_state['h_last_5_games_wins'],
             'h_last_5_games_loss': game_state['h_last_5_games_loss'],
             'h_last_5_games_draw': game_state['h_last_5_games_draw'],
             'h_last_5_games_scored': game_state['h_last_5_games_scored'],
             'h_last_5_games_conced': game_state['h_last_5_games_conced'],
             'h_last_5_games_goal_diff': game_state['h_last_5_games_goal_diff'],
             'h_last_5_games_clean': game_state['h_last_5_games_clean'],
             'h_last_5_games_failed': game_state['h_last_5_games_failed'],

             'a_won': game_state['a_won'],
             'a_won_a': game_state['a_won_a'], 'a_drawn': game_state['a_drawn'],
             'a_drawn_a': game_state['a_drawn_a'],
             'a_lost': game_state['a_lost'], 'a_lost_a': game_state['a_lost_a'], 'a_points': game_state['a_points'],
             'a_points_a': game_state['a_points_a'], 'a_scored': game_state['a_scored'],
             'a_scored_a': game_state['a_scored_a'],
             'a_conced': game_state['a_conced'], 'a_conced_a': game_state['a_conced_a'],
             'a_clean': game_state['a_clean'],
             'a_clean_a': game_state['a_clean_a'], 'a_fail': game_state['a_fail'],
             'a_fail_a': game_state['a_fail_a'],
             # new away
             # goals
             'a_goal_diff': game_state['a_goal_diff'], 'a_goal_diff_a': game_state['a_goal_diff_a'],
             # shots
             'a_shots': game_state['a_shots'], 'a_shots_a': game_state['a_shots_a'],
             'a_shots_against': game_state['a_shots_against'],
             'a_shots_against_a': game_state['a_shots_against_a'],
             'a_shots_target': game_state['a_shots_target'], 'a_shots_target_a': game_state['a_shots_target_a'],
             'a_shots_diff_a': game_state['a_shots_diff_a'], 'a_shots_diff': game_state['a_shots_diff'],
             'a_shots_target_against': game_state['a_shots_target_against'],
             'a_shots_target_against_a': game_state['a_shots_target_against_a'],
             'a_shots_target_diff': game_state['a_shots_target_diff'],
             'a_shots_target_diff_a': game_state['a_shots_target_diff_a'],
             # hit woodwork
             # 'a_hit_woodwork': game_state['a_hit_woodwork'],
             # 'a_hit_woodwork_a': game_state['a_hit_woodwork_a'],
             # 'a_hit_woodwork_against': game_state['a_hit_woodwork_against'],
             # 'a_hit_woodwork_diff': game_state['a_hit_woodwork_diff'],
             # cards
             'a_red_cards': game_state['a_red_cards'], 'a_red_cards_a': game_state['a_red_cards_a'],
             'a_red_cards_against': game_state['a_red_cards_against'],
             'a_red_cards_diff': game_state['a_red_cards_diff'],
             'a_red_cards_against_a': game_state['a_red_cards_against_a'],
             'a_red_cards_diff_a': game_state['a_red_cards_diff_a'],
             # ranking
             'a_elo': game_state['a_elo'], 'a_fifa_rating': game_state['a_fifa_rating'],
             # streaks
             'a_current_win_streak': game_state['a_current_win_streak'],
             'a_current_no_lose_streak': game_state['a_current_no_lose_streak'],
             'a_current_lose_streak': game_state['a_current_lose_streak'],
             'a_current_no_win_streak': game_state['a_current_no_win_streak'],
             # last status
             'a_last_5_games_points': game_state['a_last_5_games_points'],
             'a_last_5_games_wins': game_state['a_last_5_games_wins'],
             'a_last_5_games_loss': game_state['a_last_5_games_loss'],
             'a_last_5_games_draw': game_state['a_last_5_games_draw'],
             'a_last_5_games_scored': game_state['a_last_5_games_scored'],
             'a_last_5_games_conced': game_state['a_last_5_games_conced'],
             'a_last_5_games_goal_diff': game_state['a_last_5_games_goal_diff'],
             'a_last_5_games_clean': game_state['a_last_5_games_clean'],
             'a_last_5_games_failed': game_state['a_last_5_games_failed'],
             'h2h_win_clean': h2h_list[i][0], 'h2h_goal_clean': h2h_list[i][1], 'h2h_weight': h2h_list[i][2],
             # odds
             'home_odd': game_state['home_odd'], 'draw_odd': game_state['draw_odd'],
             'home_odd_3': game_state['home_odd_3'], 'draw_odd_3': game_state['draw_odd_3'], 'away_odd_3': game_state['away_odd_3'],
             'away_odd': game_state['away_odd'],
             'RESULT': game_state['RESULT']})
