from sklearn import tree
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier
import LinearReg
# For the First features presentation:

# simple tree
# Use 51 features (50%)
import LogiReg
import MultiReg

F_tree_1 = tree.DecisionTreeClassifier(min_samples_leaf=35, min_samples_split=35, max_depth=18, criterion='gini',
                                  class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, random_state=42)

# Use 76 features (75%)
F_tree_2 = tree.DecisionTreeClassifier(min_samples_leaf=99, min_samples_split=99, max_depth=8, criterion='entropy',
                                  class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, random_state=42)


# Forest
# Use 102 features (100%)
F_forest_1 = RandomForestClassifier(n_estimators=45, min_samples_split=18, min_samples_leaf=18, max_depth=30,
                                  criterion='entropy', class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584},
                                  max_features='sqrt',random_state=42)
# Use 91 features (90%)
F_forest_2 = RandomForestClassifier(n_estimators=25, min_samples_split=6, min_samples_leaf=6, max_depth=40,
                                  criterion='gini', class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584},
                                  max_features='sqrt',random_state=42)
# Use 76 features (75%)
F_forest_3 = RandomForestClassifier(n_estimators=46, min_samples_split=11, min_samples_leaf=11, max_depth=36,
                                  criterion='gini', class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584},
                                  max_features='sqrt',random_state=42)
#extra random forest
# Use 102 features (100%)
F_extra_1 = ExtraTreesClassifier(n_estimators=25, min_samples_leaf=13, min_samples_split=13, max_depth=37,
                               criterion='gini', class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584},
                               max_features='log2', random_state=42)
# GradientBoosting
# Use 102 features (100%)
F_grad_1_zero = GradientBoostingClassifier(n_estimators=72, min_samples_split=25, min_samples_leaf=25, max_depth=16,
                                         learning_rate=0.08, subsample=1, max_features='log2',
                                         random_state=42, init='zero')
# Use 102 features (100%)
F_base_tree = tree.DecisionTreeClassifier(random_state=42)
F_grad_1_tree = GradientBoostingClassifier(n_estimators=95, min_samples_split=41, min_samples_leaf=41, max_depth=16,
                                         learning_rate=0.1, subsample=0.75, max_features='log2',
                                         random_state=42, init=F_base_tree)

# Use 91 features (90%)
F_base_tree = tree.DecisionTreeClassifier(random_state=42)
F_grad_2_tree = GradientBoostingClassifier(n_estimators=25, min_samples_split=29, min_samples_leaf=29, max_depth=None,
                                         learning_rate=0.08, subsample=0.5, max_features='log2',
                                         random_state=42, init=F_base_tree)

# Use 76 features (75%)
F_base_tree = tree.DecisionTreeClassifier(min_samples_leaf=99, min_samples_split=99, max_depth=8, criterion='entropy',
                                  class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, random_state=42)
F_grad_3_tree = GradientBoostingClassifier(n_estimators=64, min_samples_split=44, min_samples_leaf=44, max_depth=10,
                                         learning_rate=0.08, subsample=0.5, max_features='log2',
                                         random_state=42, init=F_base_tree)

# Linear Regression
# Use 102 features (100%)
params = {'solver': 'svd', 'alpha': 0.2, 'fit':True, 'norm': False}
F_ridge = LinearReg.LinearRegSoccerGame(best_features, results, 'ridge', params)

# Use 51 features (50%)
params = {'alpha': 0.2, 'fit':True, 'norm':False, 'l1': 1.4}
F_elastic_net = LinearReg.LinearRegSoccerGame(best_features, results, 'elasticnet', params)

# Logistic Regression
# Use 25 features (25%)
params = {'c': 0.1, 'fit': True, 'norm': False, 'weigths': 1}
F_logi_lbfgs = LogiReg.LogiRegSoccerGame_lbf(best_features, results, params)

# Multi Logistic Regression
# Use 102 features (100%)
params = {'c': 1, 'fit':True, 'norm':False, 'weigths': {0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, 'l1': 0.4}
F_multi_saga_1 = MultiReg.MultiRegSoccerGame_saga(best_features, results, params)

params = {'c': 1, 'fit':True, 'norm':True, 'weigths': {0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, 'l1': 0.6}
F_multi_saga_2 = MultiReg.MultiRegSoccerGame_saga(best_features, results, params)

# Use 91 features (90%)
params = {'c': 0.4, 'fit':True, 'norm':True, 'weigths': {0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, 'l1': 0.8}
F_multi_saga_3 = MultiReg.MultiRegSoccerGame_saga(best_features, results, params)

# For the Second features presentation:

# simple tree
# Use 54 features (100%)
S_tree_1 = tree.DecisionTreeClassifier(min_samples_leaf=7, min_samples_split=7, max_depth=15, criterion='gini',
                                  class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, random_state=42)

# Use 27 features (50%)
S_tree_2 = tree.DecisionTreeClassifier(min_samples_leaf=6, min_samples_split=6, max_depth=12, criterion='entropy',
                                  class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, random_state=42)


# Forest
# Use 27 features (50%)
S_forest_1 = RandomForestClassifier(n_estimators=100, min_samples_split=3, min_samples_leaf=3, max_depth=21,
                                  criterion='gini', class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584},
                                  max_features='sqrt', random_state=42)

#extra random forest
# Use 41 features (75%)
S_extra_1 = ExtraTreesClassifier(n_estimators=40, min_samples_leaf=3, min_samples_split=3, max_depth=27,
                               criterion='entropy', class_weight={0.0: 1, 1.0: 1, 2.0: 1},
                               max_features='log2', random_state=42)

# GradientBoosting
# Use 27 features (50%)
grad_1_zero = GradientBoostingClassifier(n_estimators=72, min_samples_split=25, min_samples_leaf=25, max_depth=16,
                                         learning_rate=0.08, subsample=1, max_features='log2',
                                         random_state=42, init='zero')

# Use 27 features (50%)
base_tree = tree.DecisionTreeClassifier(min_samples_leaf=6, min_samples_split=6, max_depth=12, criterion='entropy',
                                  class_weight={0.0: 2.15865, 1.0: 3.84336, 2.0: 3.61584}, random_state=42)
grad_1_tree = GradientBoostingClassifier(n_estimators=95, min_samples_split=41, min_samples_leaf=41, max_depth=16,
                                         learning_rate=0.1, subsample=0.75, max_features='log2',
                                         random_state=42, init=base_tree)

# Linear Regression
# Use 54 features (100%)
params = {'alpha': 0.2, 'fit':True, 'norm':False, 'l1': 1.4}
S_elastic_net = LinearReg.LinearRegSoccerGame(best_features, results, 'elasticnet', params)

# Logistic Regression
# Use 54 features (100%)
params = {'c': 0.4, 'fit': True, 'norm': False, 'weigths': 0, 'l1': 0.9}
S_logi_saga = LogiReg.LogiRegSoccerGame_saga(best_features, results, params)

# Multi Logistic Regression
# Use 54 features (100%)
params = {'c': 0.1, 'fit': False, 'norm': False, 'weigths': {0.0: 1, 1.0: 1, 2.0: 1}}
S_multi_saga = MultiReg.MultiRegSoccerGame_sag(best_features, results, params)


